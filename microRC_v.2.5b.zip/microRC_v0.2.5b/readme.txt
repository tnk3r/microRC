# AUTHOR : tink3r

#v0.2.5b

#remote.syst3m@gmail.com or tink3r@unknownode.info
# Please Ask for Fork Request for any new additional features that have been added.

# Tkinter was used for beginning developers to start with un-modified linux/mac python environment
# I created this software during a prep week to control a 360 degree Camera array over wireless with low bandwidth connectivity.

# Get Camera status is not implemented. It increases traffic on triangulated radios and increases pps dramatically. Therefore it was not implemented.
# It would need an additional thread and parser to get status, this is not included in this script. I dont recommend adding it to this utility.

#Give thanks to original author: tink3r

# Homie don’t right click. can’t open it don’t own it. keep it down right dirty nerdy, son 
# don’t ask me to setup your network. Ask your IT dept.

# I don’t acknowledge use if this software. Use AT YOUR OWN RISK!! I am not responsible.